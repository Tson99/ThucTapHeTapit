# Triggering a Cloud Composer DAG from Cloud Functions

This sample executes a DAG in Cloud Composer whenever a file is added to a Cloud Storage bucket.

See the [Triggering DAGs tutorial](https://cloud.google.com/composer/docs/how-to/using/triggering-with-gcf)
for more information on using this sample.
