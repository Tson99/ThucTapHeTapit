# Test public certificate files

The public certificates in this folder are only provided for testing and should
not be used for registering your devices.
